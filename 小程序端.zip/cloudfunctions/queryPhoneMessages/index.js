// 云函数入口文件
const mysql = require('mysql2/promise');

// 创建数据库连接配置
const config = {
  host: '123.207.43.157',
  port: 3306,
  user: 'snsapi',
  password: 'snsapi',
  database: 'snsapi'
};

// 云函数入口函数
exports.main = async (event, context) => {
  const { phoneNumber } = event;
  
  console.log('收到查询请求，手机号：', phoneNumber);
  
  try {
    // 创建数据库连接
    console.log('正在连接数据库...');
    const connection = await mysql.createConnection(config);
    console.log('数据库连接成功');
    
    // 查询数据
    console.log('执行查询...');
    const [rows] = await connection.execute(
      'SELECT * FROM zf WHERE phone = ? ORDER BY time DESC',
      [phoneNumber]
    );
    console.log('查询结果：', rows);
    
    // 关闭连接
    await connection.end();
    console.log('数据库连接已关闭');
    
    // 检查查询结果
    if (!rows || rows.length === 0) {
      console.log('未找到相关记录');
      return {
        success: true,
        data: []
      };
    }
    
    return {
      success: true,
      data: rows
    };
  } catch (error) {
    console.error('操作失败：', error);
    return {
      success: false,
      error: error.message || '查询失败'
    };
  }
}