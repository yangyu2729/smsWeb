// index.js
Page({
  data: {
    phoneNumber: '',
    queryResult: '请输入手机号进行查询',
    messages: []
  },

  onPhoneInput(e) {
    this.setData({
      phoneNumber: e.detail.value
    })
  },

  onQuery() {
    const phoneNumber = this.data.phoneNumber
    if (!phoneNumber || phoneNumber.length !== 11) {
      wx.showToast({
        title: '请输入正确的手机号',
        icon: 'none'
      })
      return
    }

    wx.showLoading({
      title: '查询中...',
    })

    wx.cloud.callFunction({
      name: 'queryPhoneMessages',
      data: {
        phoneNumber: phoneNumber
      },
      success: res => {
        wx.hideLoading()
        if (res.result.success) {
          if (res.result.data && res.result.data.length > 0) {
            this.setData({
              messages: res.result.data,
              queryResult: ''
            })
          } else {
            this.setData({
              messages: [],
              queryResult: '暂无相关记录'
            })
          }
        } else {
          this.setData({
            messages: [],
            queryResult: '查询失败：' + res.result.error
          })
        }
      },
      fail: err => {
        wx.hideLoading()
        console.error('查询失败：', err)
        this.setData({
          messages: [],
          queryResult: '查询失败，请稍后重试'
        })
        wx.showToast({
          title: '查询失败，请稍后重试',
          icon: 'none'
        })
      }
    })
  }
})
