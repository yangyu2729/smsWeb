Page({
  data: {
    responses: []
  },

  formatDateTime() {
    const date = new Date();
    return date.toLocaleString('zh-CN', { hour12: false });
  },

  addResponse(message, success) {
    const responses = [{
      time: this.formatDateTime(),
      message: message,
      success: success
    }, ...this.data.responses];

    // 最多保留20条记录
    if (responses.length > 20) {
      responses.pop();
    }

    this.setData({ responses });
  },

  onSubmit(e) {
    const formData = e.detail.value;
    
    // 表单验证
    if (!formData.sim_slot || !formData.phone_numbers || !formData.msg_content) {
      this.addResponse('请填写所有必填字段', false);
      return;
    }

    // 显示加载提示
    wx.showLoading({
      title: '发送中...',
    });

    // 构建请求数据
    const requestData = {
      data: {
        sim_slot: formData.sim_slot,
        phone_numbers: formData.phone_numbers,
        msg_content: formData.msg_content
      },
      timestamp: Date.now()
    };

    // 发送请求
    wx.request({
      url: 'https://smsfd.ncncy.com/sms/send',
      method: 'POST',
      data: requestData,
      header: {
        'content-type': 'application/json'
      },
      success: (res) => {
        wx.hideLoading();
        if (res.statusCode === 200) {
          const message = `请求成功：\n${JSON.stringify(res.data, null, 2)}`;
          this.addResponse(message, true);
        } else {
          this.addResponse(`请求失败：${res.statusCode}`, false);
        }
      },
      fail: (error) => {
        wx.hideLoading();
        this.addResponse(`请求发生错误：${error.errMsg}`, false);
      }
    });
  }
});
